<?php $__env->startSection('title', 'Seller'); ?>

<?php $__env->startSection('content'); ?>
    <section class="seller">
        <div class="container">
            <div class="blog__title">
                Seller
            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card__list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card__item" title="<?php echo e($product->title); ?>">
                            <div class="card__item-image">
                                <?php if(\App\Models\Shop\Product::whereId($product->product_id)->first()->file != null): ?>
                                    <img src="<?php echo e(Storage::url(\App\Models\Shop\Product::whereId($product->product_id)->first()->file)); ?>" alt="Фото продукта">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('not-photo.jpg')); ?>" alt="Фото продукта">
                                <?php endif; ?>
                            </div>
                            <div class="card__header">
                                <div class="card__text">
                                    <div class="card__title">
                                        <?php echo e(\App\Models\Shop\Product::whereId($product->product_id)->first()->title); ?>

                                    </div>
                                    <div class="card__description">
                                        <?php echo \App\Models\Shop\Product::whereId($product->product_id)->first()->content; ?>

                                    </div>
                                </div>
                                <form action="<?php echo e(route('shop.seller.update', $product->id)); ?>" method="post" class="seller__status" >
                                    <?php echo csrf_field(); ?>
                                    <select class="seller__select" name="status">
                                        <option value="<?php echo e($product->status); ?>"><?php echo e($product->status); ?></option>
                                        <option value="On confirmation">On confirmation</option>
                                        <option value="Order is accepted">Order is accepted</option>
                                        <option value="Order collected">Order collected</option>
                                        <option value="Order sent">Order sent</option>
                                        <option value="Order arrived">Order arrived</option>
                                        <option value="Completed">Completed</option>
                                    </select>

                                    <input type="submit" value=" " class="seller-btn" title="Обновить статус">
                                </form>
                            </div>
                            <div class="card__amount">
                                <?php echo e($product->amount); ?>

                            </div>
                            <div class="card__price">
                                <?php echo e($product->total_price); ?>$
                            </div>
                            <a href="<?php echo e(route("shop.product.show", $product->product_id)); ?>" class="card__item-link" title="<?php echo e($product->address); ?>">

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(empty($products[0])): ?>
                            <div class="empty">
                                Order empty
                            </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/seller/index.blade.php ENDPATH**/ ?>