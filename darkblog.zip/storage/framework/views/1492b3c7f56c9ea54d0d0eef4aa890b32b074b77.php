<?php $__env->startSection('title', 'Draft'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Draft Post
            </div>
            <div class="blog__inner">
                <?php echo $__env->make('layout.blogMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="blog__list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog__list-item">
                            <div class="blog__item-name">
                                <a href="<?php echo e(route('blog.posts.show', $post->id)); ?>" class="post-title">
                                    <?php echo e(strip_tags($post->title)); ?>

                                </a>
                                <a class="post-category" href="<?php echo e(route('blog.category.show', $post->category_id)); ?>">
                                    <?php echo e(\App\Models\Blog\Category::withTrashed()->find($post->category_id)->title); ?>

                                </a>
                            </div>
                            <div class="blog__item-short-text">
                                <?php echo strip_tags($post->content); ?>

                            </div>
                            <div class="blog__item-footer">
                                <div class="blog__item-author">
                                    <a href="<?php echo e(route('profile.index', \App\Models\User::find($post->user_id)->nickname)); ?>" class="blog__item-author-profile">
                                        <?php echo e('@' . \App\Models\User::find($post->user_id)->nickname); ?>

                                    </a>
                                </div>
                                <div class="blog__item-public">
                                    Public: <?php echo e($post->created_at); ?>

                                </div>
                                <a class="blog__item-read-btn" href="<?php echo e(route('blog.myblog.edit', $post->id)); ?>">
                                    Change
                                </a>
                                <a class="blog__item-read-btn" href="<?php echo e(route('blog.draft.update', $post->id)); ?>">
                                    Public
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($posts->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/blog/draft/index.blade.php ENDPATH**/ ?>