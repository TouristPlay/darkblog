<?php $__env->startSection('title', 'Profile'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <?php echo e(Auth::user()->nickname); ?> profile
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Personal Data
                </div>
                <div class="profile__inner">
                    <div class="profile__nav">
                        <ul class="profile__nav-list">
                            <li class="profile__list-item">
                                <a href="" class="profile__item-link">
                                    Personal Data
                                </a>
                            </li>
                            <li class="profile__list-item">
                                <a href="" class="profile__item-link">
                                    Statistic
                                </a>
                            </li>
                            <li class="profile__list-item">
                                <a href="" class="profile__item-link">
                                    Favorite
                                </a>
                            </li>
                        </ul>
                    </div>
                    <div class="profile__main">
                        <div class="user__data">
                            <div class="label-text">
                                Your name
                            </div>
                            <div class="user-text">
                                <?php echo e(strip_tags(Auth::user()->name)); ?> <?php echo e(strip_tags(Auth::user()->lastname)); ?>

                            </div>
                        </div>
                        <div class="user__data">
                            <div class="label-text">
                                Your email
                            </div>
                            <div class="user-text">
                                <?php echo e(Auth::user()->email); ?>

                            </div>
                        </div>
                        <div class="user__data">
                            <div class="label-text">
                                Your nickname
                            </div>
                            <div class="user-text">
                                <?php echo e(Auth::user()->nickname); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/start/index.blade.php ENDPATH**/ ?>
