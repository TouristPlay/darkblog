<?php $__env->startSection('title', 'Forum'); ?>

<?php $__env->startSection('content'); ?>
    <section class="forum">
        <div class="container">
            <div class="forum__title">
                Forum
            </div>
            <div class="forum__inner">
                <?php echo $__env->make('layout.ForumMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="forum__list">
                    
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/forum/discussions/index.blade.php ENDPATH**/ ?>