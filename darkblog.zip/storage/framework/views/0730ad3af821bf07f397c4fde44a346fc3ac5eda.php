<div class="profile__nav">
    <ul class="blog__nav-list">
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.product.index')); ?>" class="blog__item-link">
                Product
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.mycard.index')); ?>" class="blog__item-link">
                MyCard
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.seller.index')); ?>" class="blog__item-link">
                Seller
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.category.index')); ?>" class="blog__item-link">
                Category
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.favorite.index')); ?>" class="blog__item-link">
                Favorite
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.card.index')); ?>" class="blog__item-link">
                Card<sup class="product__card-counter"><?php echo e(\App\Models\Shop\Order::whereUserId(Auth::id())->whereStatus('card')->count()); ?></sup>
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('shop.order.index')); ?>" class="blog__item-link">
                Order
            </a>
        </li>
    </ul>
</div>
<?php /**PATH D:\darkblog\resources\views/layout/shopMenu.blade.php ENDPATH**/ ?>