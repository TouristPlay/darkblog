<?php $__env->startSection('title', 'Order'); ?>

<?php $__env->startSection('content'); ?>
    <section class="order">
        <div class="container">
            <div class="blog__title">
                Order
            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card__list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card__item" title="<?php echo e($product->title); ?>">
                            <div class="card__item-image">
                                <img src="
                                    <?php if(\App\Models\Shop\Product::whereId($product->product_id)->first()->file != null): ?>
                                         <?php echo e(Storage::url(\App\Models\Shop\Product::whereId($product->product_id)->first()->file)); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('not-photo.jpg')); ?>

                                    <?php endif; ?>" alt="Фото продукта">
                                <?php if($product->status != 'Completed'): ?>
                                    <div class="card__setting">
                                        <a class="setting__card" title="Отменить заказ" href="<?php echo e(route('shop.order.delete', $product->id)); ?>">
                                            <img src="https://img.icons8.com/glyph-neue/32/000000/undo.png"/>
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="card__header">
                                <div class="card__text">
                                    <div class="card__title">
                                        <?php echo e(\App\Models\Shop\Product::whereId($product->product_id)->first()->title); ?>

                                    </div>
                                    <div class="card__description">
                                        <?php echo \App\Models\Shop\Product::whereId($product->product_id)->first()->content; ?>

                                    </div>
                                </div>
                                <div class="card__status">
                                    <?php echo e($product->status); ?>

                                </div>
                                <div class="card__amount" title="Количество">
                                   <?php echo e($product->amount); ?>

                                </div>
                            </div>
                            <div class="card__price">
                                <?php echo e($product->total_price); ?>$
                            </div>
                            <a href="" class="card__item-link" title="<?php echo e($product->address); ?>">

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(empty($products[0])): ?>
                            <div class="empty">
                                Order empty
                            </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/order/index.blade.php ENDPATH**/ ?>