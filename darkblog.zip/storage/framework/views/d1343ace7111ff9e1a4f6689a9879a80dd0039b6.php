<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!-- include libraries(jQuery, bootstrap) -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

    <!-- include summernote css/js -->
    <link href="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote.min.js"></script>

    <link rel="stylesheet" href="<?php echo e(asset("/css/style.css")); ?>">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset("favicon.ico")); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap" rel="stylesheet">
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>
<body>
<div class="header">
    <div class="container">
        <div class="header__inner">
            <div class="header__logo">
                <a href="/" class="header__logo-link">
                    DarkBlog
                </a>
            </div>
            <nav class="header__nav">
                <ul class="header__list">
                    <li class="header__list-item">
                        <a href="<?php echo e(route('blog.posts.index')); ?>" class="header__item-link">
                            Blog
                        </a>
                    </li>
                    <li class="header__list-item">
                        <a href="" class="header__item-link">
                            Shop
                        </a>
                    </li>
                    <li class="header__list-item">
                        <a href="<?php echo e(route('forum.topic.index')); ?>" class="header__item-link">
                            Forum
                        </a>
                    </li>
                    <li class="header__list-item">
                        <a href="<?php echo e(route('profile.index', Auth::user()->nickname)); ?>" class="header__item-link">
                            <?php echo e(strip_tags(Auth::user()->nickname)); ?>

                        </a>
                    </li>
                    <li class="header__list-item">
                        <a href="<?php echo e(route('logout')); ?>" class="header__item-link-logout">
                            <img src="https://img.icons8.com/ios/50/ffffff/exit.png"/>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?php echo $__env->yieldContent('content'); ?>

<script src="<?php echo e(asset('/js/main.js')); ?>"></script>
</body>
</html>
<?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/layout/main-layout.blade.php ENDPATH**/ ?>