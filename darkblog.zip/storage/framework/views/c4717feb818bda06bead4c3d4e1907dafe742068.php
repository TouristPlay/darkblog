<?php $__env->startSection('title', 'BlogCategory'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <a href="<?php echo e(route('admin.index')); ?>" class="admin-link">
                    Admin Panel
                </a>
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Posts
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table admin__category">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Posts</th>
                                    <th scope="col">ShowPost</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row"></th>
                                <td>
                                    <form method="post" class="admin_category-form" action="<?php echo e(route('admin.categories.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input title="Enter Category" placeholder="Gun" type="text" class="admin_category-input" name="title" autofocus>
                                        <input title="Create Category" type="submit" value="" class="admin-submit_btn create-category">
                                    </form>
                                </td>

                            </tr>
                               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="Category Id" scope="row"><?php echo e($category->id); ?></th>
                                       <td>
                                           <form method="post" class="admin_category-form" action="<?php echo e(route('admin.categories.update', $category->id)); ?>">
                                               <?php echo csrf_field(); ?>
                                               <input title="Enter Category" type="text" class="admin_category-input" name="title" autofocus value="<?php echo e($category->title); ?>">
                                               <input title="Update Category" type="submit" value="" class="admin-submit_btn update-category">
                                           </form>
                                       </td>
                                       <td title="Use Category Counter"><?php echo e($category->post_counter); ?></td>
                                       <td>
                                           <a href="<?php echo e(route('blog.category.show', $category->id)); ?>" title="Show Category Post" class="link">
                                               <img src="https://img.icons8.com/office/20/000000/show-password.png"/>
                                           </a>
                                       </td>
                                       <td>
                                           <?php if($category->deleted_at == null): ?>
                                               <a href="<?php echo e(route('admin.categories.delete', $category->id)); ?>" title="Delete Category" class="admin-delete">
                                                   <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                               </a>
                                           <?php else: ?>
                                               <a href="<?php echo e(route('admin.categories.restore', $category->id)); ?>" title="Restore Category" class="admin-delete">
                                                   <img src="https://img.icons8.com/fluency/20/000000/settings-backup-restore.png"/>
                                               </a>
                                           <?php endif; ?>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($categories->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/admin/categories/index.blade.php ENDPATH**/ ?>
