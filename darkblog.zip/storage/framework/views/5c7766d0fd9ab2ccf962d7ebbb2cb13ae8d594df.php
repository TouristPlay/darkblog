<?php $__env->startSection('title', 'MyBlog'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                MyBlog Post
                <a href="<?php echo e(route('blog.myblog.create')); ?>" class="create-btn">
                    Create
                </a>
            </div>
            <div class="blog__inner">
                <?php echo $__env->make('layout.sidebarMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="blog__list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog__list-item">
                            <div class="blog__item-name">
                                <a href="<?php echo e(route('blog.posts.show', $post->id)); ?>" class="post-title">
                                    <?php echo e(strip_tags($post->title)); ?>

                                </a>
                                <div class="myblog_link">
                                    <a class="post-category" href="<?php echo e(route('blog.category.show', $post->category_id)); ?>">
                                        <?php echo e(\App\Models\Blog\Category::withTrashed()->find($post->category_id)->title); ?>

                                    </a>
                                    <a href="<?php echo e(route('blog.myblog.delete', $post->id)); ?>" class="delete-post">
                                        <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                    </a>
                                </div>
                            </div>
                            <div class="blog__item-short-text">
                                <?php echo strip_tags($post->content); ?>

                            </div>
                            <div class="blog__item-footer">
                                <div class="blog__item-author">
                                    <a href="<?php echo e(route('profile.index', \App\Models\User::find($post->user_id)->nickname)); ?>" class="blog__item-author-profile">
                                        <?php echo e('@' . \App\Models\User::find($post->user_id)->nickname); ?>

                                    </a>
                                </div>
                                <div class="blog__item-public">
                                    Public: <?php echo e($post->created_at); ?>

                                </div>
                                <a class="blog__item-read-btn" href="<?php echo e(route('blog.posts.show', $post->id)); ?>">
                                    Read Post
                                </a>
                                <a class="blog__item-read-btn" href="<?php echo e(route('blog.myblog.edit', $post->id)); ?>">
                                    Change
                                </a>
                                <?php echo $__env->make('layout.favorite-icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($posts->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/blog/myblog/index.blade.php ENDPATH**/ ?>