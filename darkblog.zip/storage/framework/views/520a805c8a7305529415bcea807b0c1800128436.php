<?php $__env->startSection('title', 'Card'); ?>

<?php $__env->startSection('content'); ?>
    <section class="card">
        <div class="container">
            <div class="blog__title">
                Card
            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card__list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="card__item" title="<?php echo e($product->title); ?>">
                            <div class="card__item-image">
                                <img src="
                                    <?php if(\App\Models\Shop\Product::whereId($product->product_id)->first()->file != null): ?>
                                        <?php echo e(Storage::url(\App\Models\Shop\Product::whereId($product->product_id)->first()->file)); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('not-photo.jpg')); ?>

                                    <?php endif; ?>" alt="Фото продукта">
                                <div class="card__setting">
                                    <a class="setting__card" title="Удалить" href="<?php echo e(route('shop.card.delete', $product->id)); ?>">
                                        <img src="https://img.icons8.com/ios/32/000000/delete--v1.png"/>
                                    </a>
                                </div>
                            </div>
                            <div class="card__header">
                                <div class="card__text">
                                    <div class="card__title">
                                        <?php echo e(\App\Models\Shop\Product::whereId($product->product_id)->first()->title); ?>

                                    </div>
                                    <div class="card__description">
                                        <?php echo \App\Models\Shop\Product::whereId($product->product_id)->first()->content; ?>

                                    </div>
                                </div>
                                <div class="card__amount" title="Количество">
                                    <form action="<?php echo e(route('shop.card.update', $product->id)); ?>" method="post" autocomplete="off" class="card__form">
                                        <?php echo csrf_field(); ?>
                                        <input type="number" min="1" onchange="priceChange(this)" max="<?php echo e(\App\Models\Shop\Product::whereId($product->product_id)->first()->amount); ?>" name="amount" class="card__input" value="<?php echo e($product->amount); ?>">
                                        <input type="submit" value=" " class="card-btn">
                                    </form>
                                </div>
                            </div>
                            <div class="card__price"e>
                                <?php echo e($product->total_price); ?>$
                            </div>
                            <a href="<?php echo e(route("shop.product.show", $product->product_id)); ?>" class="card__item-link">

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if(!empty($products[0])): ?>
                            <div class="card__total">
                                <div class="card__header">
                                    <div class="card__total-title">
                                        Total:
                                    </div>
                                </div>
                                <div class="card__price">
                                    <?php echo e($products->sum('total_price')); ?>$
                                </div>
                                <form action="<?php echo e(route('shop.order.store')); ?>" method="post"  class="card-order__form">
                                    <?php echo csrf_field(); ?>
                                    <label class="card__label">
                                        <div class="label-text">
                                            Enter address
                                        </div>
                                        <input type="text" name="address" class="order__input" value="<?php echo e(old('address')); ?>">
                                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                             <div class="form_error-msg"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </label>
                                    <input type="submit" value="Order"  class="order__btn"
                                           <?php if($products->sum('total_price') > \App\Models\Profile\Balance::whereUserId(Auth::id())->first()->balance): ?>
                                                disabled title="Недостаточно средств для покупки"
                                           <?php endif; ?>
                                    >
                                </form>
                            </div>
                        <?php else: ?>
                            <div class="empty">
                                Card empty
                            </div>
                        <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/card/index.blade.php ENDPATH**/ ?>