<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Blog List
            </div>
            <div class="blog__inner">
                <div class="profile__nav">
                    <ul class="blog__nav-list">
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('blog')); ?>" class="blog__item-link">
                                Posts
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('myblog')); ?>" class="blog__item-link">
                                MyBlog
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('category')); ?>" class="blog__item-link">
                                Category
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="" class="blog__item-link">
                                Favorite
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="blog__list">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog__list-item">
                            <div class="blog__item-name">
                                <?php echo e(strip_tags($post->title)); ?>

                            </div>
                            <div class="blog__item-short-text">
                                <?php echo strip_tags($post->content); ?>

                            </div>
                            <div class="blog__item-footer">
                                <div class="blog__item-author">
                                    <a href="" class="blog__item-author-profile">
                                        <?php echo e('@' . \App\Models\User::find($post->user_id)->nickname); ?>

                                    </a>
                                </div>
                                <div class="blog__item-public">
                                    Public time: <?php echo e($post->created_at); ?>

                                </div>
                                <a class="blog__item-read-btn" href="<?php echo e(route('readpost', $post->id)); ?>">
                                    Read Post
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/start/index.blade.php ENDPATH**/ ?>
