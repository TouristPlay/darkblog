<?php $__env->startSection('title', 'MyBlog'); ?>

<?php $__env->startSection('content'); ?>
    <section class="forum">
        <div class="container">
            <div class="blog__title">
                My Topics
                <a href="<?php echo e(route('forum.mytopic.create')); ?>" class="create-btn">
                    Create
                </a>
            </div>
            <div class="blog__inner">
                <?php echo $__env->make('layout.ForumMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="blog__list">
                    <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="blog__list-item topic__list-item">
                            <div class="blog__item-name topic__item-name">
                                <a href="<?php echo e(route('forum.topic.show', $topic->id)); ?>" class="post-title">
                                    <?php echo e(strip_tags($topic->title)); ?>

                                    <div class="topic_status">
                                        <?php if($topic->status === 'open'): ?>
                                            <img title="This topic open" src="https://lun-eu.icons8.com/a/V8RdbZ-EZEqPJtQNGYecLA/xIl7OgcUOEmAMBKoLXA1cA/id%3DMR7Wh2bERF5j-format%3Dpng.png"/>
                                        <?php else: ?>
                                            <img title="This topic close" src="https://lun-eu.icons8.com/a/V8RdbZ-EZEqPJtQNGYecLA/GWeG4ndTHkWsHPo46BPVBA/id%3DeIN3yzdnX3bq-format%3Dpng.png"/>
                                        <?php endif; ?>
                                    </div>
                                </a>
                                <div class="myblog_link">
                                    <a class="post-category" href="<?php echo e(route('forum.topic.show', $topic->rubric_id)); ?>">
                                        <?php echo e(\App\Models\Forum\Rubric::find($topic->rubric_id)->title); ?>

                                    </a>
                                    <div class="message_count">
                                        <img src="https://img.icons8.com/office/20/000000/chat-message.png"/>
                                        <?php echo e($topic->message_counter); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="blog__item-footer topic__item-footer">
                                <div class="blog__item-author">
                                    <a href="<?php echo e(route('profile.index', \App\Models\User::find($topic->user_id)->nickname)); ?>" class="blog__item-author-profile">
                                        <?php echo e('@' . \App\Models\User::find($topic->user_id)->nickname); ?>

                                    </a>
                                </div>
                                <div class="blog__item-public">
                                    Public: <?php echo e($topic->created_at); ?>

                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($topics->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/forum/mytopic/index.blade.php ENDPATH**/ ?>