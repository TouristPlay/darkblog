<div class="profile__nav">
    <ul class="blog__nav-list">
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('forum.topic.index')); ?>" class="blog__item-link">
                Topic
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('forum.mytopic.index')); ?>" class="blog__item-link">
                MyTopic
            </a>
        </li>
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('forum.rubric.index')); ?>" class="blog__item-link">
                Rubric
            </a>
        </li>
    </ul>
</div>
<?php /**PATH D:\darkblog\resources\views/layout/ForumMenu.blade.php ENDPATH**/ ?>