<?php $__env->startSection('title', 'Topics'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <a href="<?php echo e(route('admin.index')); ?>" class="admin-link">
                    Admin Panel
                </a>
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Topics
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table admin__posts">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Nickname</th>
                                    <th scope="col">Rubric</th>
                                    <th scope="col">Message</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="Post ID" scope="row"><?php echo e($topic->id); ?></th>
                                       <td title="Post title">
                                           <a href="<?php echo e(route('forum.topic.show', $topic->id)); ?>" class="link">
                                               <?php echo e($topic->title); ?>

                                           </a>
                                       </td>
                                       <td title="User nickname">
                                           <a href="<?php echo e(route('profile.index', \App\Models\User::find($topic->user_id)->nickname)); ?>" class="link">
                                               <?php echo e(\App\Models\User::find($topic->user_id)->nickname); ?>

                                           </a>
                                       </td>
                                       <td title="Rubric title">
                                           <a  href="<?php echo e(route('forum.rubric.show', $topic->rubric_id)); ?>" class="link">
                                               <?php echo e(\App\Models\Forum\Rubric::withTrashed()->find($topic->rubric_id)->title); ?>

                                           </a>
                                       </td>
                                       <td title="Message Counter"><?php echo e($topic->message_counter); ?></td>
                                       <td title="Topic Status">
                                           <?php if($topic->status === 'open'): ?>
                                               <img title="This topic open" src="https://lun-eu.icons8.com/a/V8RdbZ-EZEqPJtQNGYecLA/xIl7OgcUOEmAMBKoLXA1cA/id%3DMR7Wh2bERF5j-format%3Dpng.png"/>
                                           <?php else: ?>
                                               <img title="This topic close" src="https://lun-eu.icons8.com/a/V8RdbZ-EZEqPJtQNGYecLA/GWeG4ndTHkWsHPo46BPVBA/id%3DeIN3yzdnX3bq-format%3Dpng.png"/>
                                           <?php endif; ?>
                                       </td>
                                       <td>
                                           <?php if($topic->deleted_at == null): ?>
                                               <a href="<?php echo e(route('admin.topics.delete', $topic->id)); ?>" title="Delete Topic" class="admin-delete">
                                                   <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                               </a>
                                           <?php else: ?>
                                               <a href="<?php echo e(route('admin.topics.restore', $topic->id)); ?>" title="Restore Topic" class="admin-delete">
                                                   <img src="https://img.icons8.com/fluency/20/000000/settings-backup-restore.png"/>
                                               </a>
                                           <?php endif; ?>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($topics->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/admin/topics/index.blade.php ENDPATH**/ ?>