<?php $__env->startSection('title', 'Users'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                Admin Panel
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Users
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Name</th>
                                    <th scope="col">Nickname</th>
                                    <th scope="col">Email</th>
                                    <th scope="col">Role</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="User ID" scope="row"><?php echo e($user->id); ?></th>
                                       <td title="User name"><?php echo e($user->name); ?> <?php echo e($user->lastname); ?></td>
                                       <td title="User nickname">
                                           <a  class="user__nickname link" href="<?php echo e(route('profile.index', $user->nickname)); ?>">
                                               <?php echo e('@'. $user->nickname); ?>

                                           </a>
                                       </td>
                                       <td title="User email"><?php echo e($user->email); ?></td>
                                       <td title="Change user role">
                                           <form action="<?php echo e(route('admin.users.update', $user->id)); ?>" method="post" class="users__form">
                                               <?php echo csrf_field(); ?>
                                               <select name="role" class="role">
                                                   <option value="admin" <?php if($user->role === 'admin'): ?> selected <?php endif; ?>>Admin</option>
                                                   <option value="user" <?php if($user->role === 'user'): ?> selected <?php endif; ?>>User</option>
                                               </select>
                                               <input type="submit" title="Update role" class="admin-submit_btn role-change" value="">
                                           </form>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($users->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/admin/users/index.blade.php ENDPATH**/ ?>