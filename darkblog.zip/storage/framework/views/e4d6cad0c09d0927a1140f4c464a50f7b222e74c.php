<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('link-text', 'Register'); ?>
<?php $__env->startSection('link-route', route('register')); ?>

<?php $__env->startSection('content'); ?>
    <section class="login">
        <div class="container">
            <div class="login__title">
                    DarkBlog Login
            </div>
            <form action="<?php echo e(route('login')); ?>" class="login__form" method="post" autocomplete="off">
                <?php echo csrf_field(); ?>
                <label class="login__label">
                    <div class="label__text">
                        Enter your email
                    </div>
                    <input type="email" autofocus class="login__input" placeholder="hask34@mail.com" name="email">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="form_error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="login__label">
                    <div class="label__text">
                        Enter password
                    </div>
                    <input type="password" class="login__input" name="password">
                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="form_error-msg"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <input type="submit" class="login-btn" value="Log In">
            </form>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout-start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/start/login.blade.php ENDPATH**/ ?>
