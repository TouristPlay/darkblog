<?php $__env->startSection('title', 'DarkBlog'); ?>
<?php $__env->startSection('link-text', 'Log In'); ?>
<?php $__env->startSection('link-route', route('login')); ?>

<?php $__env->startSection('content'); ?>
    <section class="welcome">
        <div class="container">
            <div class="welcome__inner">
                <div class="main__title">
                    <span>Welcome</span>
                    <span>to the DarkBlog</span>
                </div>
                <div class="welcome__text">
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                    Accusantium, eius eos incidunt itaque odit placeat quibusdam
                    repellendus reprehenderit suscipit voluptas. At repellat sunt
                    temporibus voluptas!
                </div>
                <div class="welcome-btn">
                    <a href="<?php echo e(route('rules')); ?>" class="register-link">
                        I ready!
                    </a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout-start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/start/welcome.blade.php ENDPATH**/ ?>
