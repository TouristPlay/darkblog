<?php $__env->startSection('title', 'DarkBlog rules'); ?>
<?php $__env->startSection('link-text', 'Log In'); ?>
<?php $__env->startSection('link-route', route('login')); ?>

<?php $__env->startSection('content'); ?>

    <section class="rules">
        <div class="container">
            <div class="rule">
                <span class="rule__title">
                    DarkBlog Rules
                </span>
                <ul class="rules__list">
                    <li class="rules__list-item">
                        The first rule of the forum is not to talk about
                    </li>
                    <li class="rules__list-item">
                        Text messaging, or texting, is the act of composing and sending
                    </li>
                    <li class="rules__list-item">
                        Text messaging, or texting, is the act of composing and sending
                    </li>
                    <li class="rules__list-item">
                        Text messaging, or texting, is the act of composing and sending
                    </li>
                    <li class="rules__list-item">
                        Text messaging, or texting, is the act of composing and sending
                    </li>
                    <li class="rules__list-item">
                        Text messaging, or texting, is the act of composing and sending
                    </li>
                </ul>
                <label class="rule-label">
                    <input type="checkbox" class="rule-checkbox" onchange="checkRuleCheckbox()">
                    I agree with the rules
                </label>
            </div>
            <div class="rule-btn">
                <a href="<?php echo e(route('register')); ?>" class="register-link disable">
                    Register
                </a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout-start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/start/rules.blade.php ENDPATH**/ ?>
