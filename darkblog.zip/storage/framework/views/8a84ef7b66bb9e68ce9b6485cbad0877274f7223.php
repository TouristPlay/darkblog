<div class="profile__nav">
    <ul class="profile__nav-list">
        <li class="profile__list-item">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="profile__item-link">
                Users
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route('admin.posts.index')); ?>" class="profile__item-link">
                Posts
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route('admin.categories.index')); ?>" class="profile__item-link">
                Categories
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route('admin.rubrics.index')); ?>" class="profile__item-link">
                Rubrics
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route('admin.topics.index')); ?>" class="profile__item-link">
                Topics
            </a>
        </li>

    </ul>
</div>
<?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/layout/adminMenu.blade.php ENDPATH**/ ?>
