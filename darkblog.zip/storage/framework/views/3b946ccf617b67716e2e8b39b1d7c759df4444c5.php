<?php if(!(\App\Models\Shop\FavoriteProduct::where('user_id', Auth::id())->where('product_id', $product->id)->get()->isEmpty())): ?>
    <a title="Favorite: <?php echo e($product->favorite_counter); ?>" class="shop__item-favorite-btn " href="<?php echo e(route('shop.favorite.delete', $product->id)); ?>">
        <img src="https://img.icons8.com/plasticine/32/000000/fire-heart.png"  class="favorite-img">
    </a>
<?php else: ?>
    <a title="Favorite: <?php echo e($product->favorite_counter); ?>" class="shop__item-favorite-btn" href="<?php echo e(route('shop.favorite.create', $product->id)); ?>">
        <img src="https://img.icons8.com/carbon-copy/32/000000/fire-heart.png"  class="favorite-img">
    </a>
<?php endif; ?>
<?php /**PATH D:\darkblog\resources\views/layout/shop_favorite_icon.blade.php ENDPATH**/ ?>