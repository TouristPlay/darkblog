<?php $__env->startSection('title', $category->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                <?php echo e($category->title); ?> product
            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="product__list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product__item" title="<?php echo e($product->title); ?>">
                            <div class="product__item-image">
                                <?php if($product->file != null): ?>
                                    <img src="<?php echo e(Storage::url($product->file)); ?>" alt="Фото продукта">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('not-photo.jpg')); ?>" alt="Фото продукта">
                                <?php endif; ?>
                                <div class="product__setting">
                                    <a class="setting__card" href="<?php echo e(route('shop.mycard.edit', $product->id)); ?>" title="Редактировать">
                                        <img src="https://img.icons8.com/fluency-systems-regular/20/000000/edit-property.png"/>
                                    </a>
                                    <div class="setting__favorite">
                                        <?php echo $__env->make('layout.shop_favorite_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="product__title">
                                <?php echo e($product->title); ?>

                            </div>
                            <div class="product__info">
                                <div class="product__price">
                                    <?php echo e($product->price); ?>$
                                </div>
                                <?php if($product->discount > 0): ?>
                                    <div class="product__price-discount">
                                        <?php echo e($product->price * ((100 - $product->discount) / 100)); ?>$
                                    </div>
                                <?php endif; ?>
                                <div class="product__amount">
                                    <?php echo e($product->amount); ?>

                                </div>
                            </div>
                            <a href="" class="product__item-link">

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($products->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/category/show.blade.php ENDPATH**/ ?>