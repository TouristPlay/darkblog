<?php $__env->startSection('title', 'Statistic'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <?php echo e($user->nickname); ?> profile
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Personal Data
                </div>
                <div class="profile__inner">
                    <?php echo $__env->make("layout.profileMenu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="profile__main">
                        <div class="counter__inner ">
                            <div class="counter__title">
                                <a title="Open all user posts" href="<?php echo e(route('blog.posts.author.show', $user->nickname)); ?>" class="link">
                                    Posts counter
                                    <img src="https://img.icons8.com/external-icongeek26-linear-colour-icongeek26/20/000000/external-search-casino-icongeek26-linear-colour-icongeek26.png"/>
                                </a>
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Blog\Post::whereUserId($user->id)->count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                <a title="Open all user topic" href="<?php echo e(route('forum.topic.author.index', $user->nickname)); ?>" class="link">
                                    Topic counter
                                    <img src="https://img.icons8.com/external-icongeek26-linear-colour-icongeek26/20/000000/external-search-casino-icongeek26-linear-colour-icongeek26.png"/>
                                </a>
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Forum\Topic::whereUserId($user->id)->count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Message counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Forum\Message::whereUserId($user->id)->count()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/profile/statistic/index.blade.php ENDPATH**/ ?>