<div class="profile__nav">
    <ul class="profile__nav-list">
        <li class="profile__list-item">
            <a href="" class="profile__item-link">
                Personal Data
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route("profile.statistic.index", $nickname)); ?>" class="profile__item-link">
                Statistic
            </a>
        </li>
        <li class="profile__list-item">
            <a href="" class="profile__item-link">
                Favorite
            </a>
        </li>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', auth()->user())): ?>
            <li class="profile__list-item">
                <a href="<?php echo e(route('admin.index')); ?>" class="profile__item-link">
                    Admin panel
                </a>
            </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/layout/profileMenu.blade.php ENDPATH**/ ?>