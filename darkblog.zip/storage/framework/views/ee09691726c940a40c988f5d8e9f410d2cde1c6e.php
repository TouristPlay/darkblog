<?php $__env->startSection('title', 'Profile'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <?php echo e($user->nickname); ?> profile
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Personal Data
                </div>
                <div class="profile__inner">
                    <?php echo $__env->make("layout.profileMenu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="profile__main">
                        <div class="user__data">
                            <div class="label-text">
                                Your name
                            </div>
                            <div class="user-text">
                                <?php echo e(strip_tags($user->name)); ?> <?php echo e(strip_tags($user->lastname)); ?>

                            </div>
                        </div>
                        <div class="user__data">
                            <div class="label-text">
                                Your email
                            </div>
                            <div class="user-text">
                                <?php echo e($user->email); ?>

                            </div>
                        </div>
                        <div class="user__data">
                            <div class="label-text">
                                Your nickname
                            </div>
                            <div class="user-text">
                                <?php echo e($user->nickname); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/profile/index.blade.php ENDPATH**/ ?>