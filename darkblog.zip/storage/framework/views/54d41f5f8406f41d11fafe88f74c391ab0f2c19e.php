<?php $__env->startSection('title', 'Rubric'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <a href="<?php echo e(route('admin.index')); ?>" class="admin-link">
                    Admin Panel
                </a>
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Rubrics
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table admin__category">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Topics</th>
                                    <th scope="col">ShowTopic</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                            <tr>
                                <th scope="row"></th>
                                <td>
                                    <form method="post" class="admin_category-form" action="<?php echo e(route('admin.rubrics.store')); ?>">
                                        <?php echo csrf_field(); ?>
                                        <input title="Enter rubric" placeholder="Gun" type="text" class="admin_category-input" name="title" autofocus>
                                        <input title="Create rubric" type="submit" value="" class="admin-submit_btn create-category">
                                    </form>
                                </td>

                            </tr>
                               <?php $__currentLoopData = $rubrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="Category Id" scope="row"><?php echo e($rubric->id); ?></th>
                                       <td>
                                           <form method="post" class="admin_category-form" action="<?php echo e(route('admin.rubrics.update', $rubric->id)); ?>">
                                               <?php echo csrf_field(); ?>
                                               <input title="Enter rubric" type="text" class="admin_category-input" name="title" autofocus value="<?php echo e($rubric->title); ?>">
                                               <input title="Update rubric" type="submit" value="" class="admin-submit_btn update-category">
                                           </form>
                                       </td>
                                       <td title="Use Category Counter"><?php echo e($rubric->topic_counter); ?></td>
                                       <td>
                                           <a href="<?php echo e(route('forum.rubric.show', $rubric->id)); ?>" title="Show Rubric Topic" class="link">
                                               <img src="https://img.icons8.com/office/20/000000/show-password.png"/>
                                           </a>
                                       </td>
                                       <td>
                                           <?php if($rubric->deleted_at == null): ?>
                                               <a href="<?php echo e(route('admin.rubrics.delete', $rubric->id)); ?>" title="Delete Rubric" class="admin-delete">
                                                   <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                               </a>
                                           <?php else: ?>
                                               <a href="<?php echo e(route('admin.rubrics.restore', $rubric->id)); ?>" title="Restore Rubric" class="admin-delete">
                                                   <img src="https://img.icons8.com/fluency/20/000000/settings-backup-restore.png"/>
                                               </a>
                                           <?php endif; ?>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($rubrics->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/admin/rubrics/index.blade.php ENDPATH**/ ?>