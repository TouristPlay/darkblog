<?php $__env->startSection('title', 'Add post'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Category
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', auth()->user())): ?>
                    <a href="<?php echo e(route('admin.categories.create')); ?>" class="create-btn">
                        Create
                    </a>
                <?php endif; ?>
            </div>
            <div class="category__inner">
                <?php echo $__env->make('layout.sidebarMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="category__list">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category__item">
                            <div class="category__item-title">
                                <a href="<?php echo e(route('blog.category.show', $category->id)); ?>" class="category__title-link">
                                    <?php echo e(strip_tags($category['title'])); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/blog/category/index.blade.php ENDPATH**/ ?>
