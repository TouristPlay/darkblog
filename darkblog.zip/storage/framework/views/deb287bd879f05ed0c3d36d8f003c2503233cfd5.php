<?php if(!(\App\Models\Blog\FavoritePost::where('user_id', Auth::id())->where('post_id', $post->id)->get()->isEmpty())): ?>
    <a title="Favorite: <?php echo e(\App\Models\Blog\Post::find($post->id)->favorite); ?>" class="blog__item-favorite-btn " href="<?php echo e(route('blog.favorite.delete', $post->id)); ?>">
        <img src="https://img.icons8.com/plasticine/32/000000/fire-heart.png"  class="favorite-img">
    </a>
<?php else: ?>
    <a title="Favorite: <?php echo e(\App\Models\Blog\Post::find($post->id)->favorite); ?>" class="blog__item-favorite-btn" href="<?php echo e(route('blog.favorite.create', $post->id)); ?>">
        <img src="https://img.icons8.com/carbon-copy/32/000000/fire-heart.png"  class="favorite-img">
    </a>
<?php endif; ?>
<?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/layout/blog_Favorite_Icon.blade.php ENDPATH**/ ?>
