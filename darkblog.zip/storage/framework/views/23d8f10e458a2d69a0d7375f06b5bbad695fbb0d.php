<?php $__env->startSection('title', 'DarkBlog rules'); ?>
<?php $__env->startSection('link-text', 'Log In'); ?>
<?php $__env->startSection('link-route', route('login')); ?>

<?php $__env->startSection('content'); ?>

    <section class="rules">
        <div class="container">
            <div class="rule">
                <span class="rule__title">
                    DarkBlog Rules
                </span>
                <ul class="rules__list">
                    <li class="rules__list-item">
                        Don't talk about the site
                    </li>
                    <li class="rules__list-item">
                        Change your IP address regularly.
                    </li>
                    <li class="rules__list-item">
                        Don't use the same nickname twice.
                    </li>
                    <li class="rules__list-item">
                        Do not talk too much about yourself online.
                    </li>
                    <li class="rules__list-item">
                        Don't show your phone number.
                    </li>
                    <li class="rules__list-item">
                        Do not use real email.
                    </li>
                </ul>
                <label class="rule-label">
                    <input type="checkbox" class="rule-checkbox" onchange="checkRuleCheckbox()">
                    I agree with the rules
                </label>
            </div>
            <div class="rule-btn">
                <a href="<?php echo e(route('register')); ?>" class="register-link disable">
                    Register
                </a>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.layout-start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/start/rules.blade.php ENDPATH**/ ?>