<?php $__env->startSection('title', 'Blog'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                <?php echo $__env->yieldContent('blog-title'); ?>
            </div>
            <div class="blog__inner">
                <div class="profile__nav">
                    <ul class="blog__nav-list">
                        <li class="blog__list-item">
                            <a href="" class="blog__item-link">
                                My Post
                            </a>
                        </li>
                        <li class="blog__list-item">
                            <a href="" class="blog__item-link">
                                Add Post
                            </a>
                        </li>
                        <li class="blog__list-item">
                            <a href="" class="blog__item-link">
                                Favorite
                            </a>
                        </li>
                    </ul>
                </div>
                <?php echo $__env->yieldContent('blog-content'); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/layout/layout-index.blade.php ENDPATH**/ ?>
