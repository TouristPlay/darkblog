<?php $__env->startSection('title', 'Posts'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <a href="<?php echo e(route('admin.index')); ?>" class="admin-link">
                    Admin Panel
                </a>
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Posts
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table admin__posts">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Nickname</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Favorite</th>
                                    <th scope="col">Published</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="Post ID" scope="row"><?php echo e($post->id); ?></th>
                                       <td title="Post title">
                                           <a href="<?php echo e(route('blog.posts.show', $post->id)); ?>" class="link">
                                               <?php echo e($post->title); ?>

                                           </a>
                                       </td>
                                       <td title="User nickname">
                                           <a href="<?php echo e(route('profile.index', \App\Models\User::find($post->user_id)->nickname)); ?>" class="link">
                                               <?php echo e(\App\Models\User::find($post->user_id)->nickname); ?>

                                           </a>
                                       </td>
                                       <td title="Post Category title">
                                           <a  href="<?php echo e(route('blog.category.show', $post->category_id)); ?>" class="link">
                                               <?php echo e(\App\Models\Blog\Category::withTrashed()->find($post->category_id)->title); ?>

                                           </a>
                                       </td>
                                       <td title="Favorite Counter"><?php echo e($post->favorite); ?></td>
                                       <td title="Post Status">
                                           <?php if($post->deleted_at == null): ?>
                                               <?php if($post->published == 1): ?>
                                                   Published
                                               <?php else: ?>
                                                   Unpublished
                                               <?php endif; ?>
                                           <?php else: ?>
                                                Deleted
                                           <?php endif; ?>
                                       </td>
                                       <td>
                                           <?php if($post->deleted_at == null): ?>
                                               <a href="<?php echo e(route('admin.posts.delete', $post->id)); ?>" title="Delete Post" class="admin-delete">
                                                   <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                               </a>
                                           <?php else: ?>
                                               <a href="<?php echo e(route('admin.posts.restore', $post->id)); ?>" title="Restore Post" class="admin-delete">
                                                   <img src="https://img.icons8.com/fluency/20/000000/settings-backup-restore.png"/>
                                               </a>
                                           <?php endif; ?>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($posts->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>