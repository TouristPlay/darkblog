<?php $__env->startSection('title', 'Balance'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <?php echo e($user->nickname); ?> profile
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Balance:<span><?php echo e(\App\Models\Profile\Balance::whereUserId(Auth::id())->first()->balance); ?>$</span>
                </div>
                <div class="profile__inner">
                    <?php echo $__env->make("layout.profileMenu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="profile__main">
                        <form action="<?php echo e(route('profile.balance.store')); ?>" class="balance__form" method="post">
                            <?php echo csrf_field(); ?>
                            <label class="balance__label">
                                <div class="label__text">
                                    Top up balance
                                </div>
                                <input type="number" class="balance__input" name="balance" value="<?php echo e(old('balance')); ?>">
                                <?php $__errorArgs = ['balance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="form_error-msg"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </label>
                            <input type="submit" class="balance-btn" value="Top Up">
                        </form>



                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/profile/balance/index.blade.php ENDPATH**/ ?>