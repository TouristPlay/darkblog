<?php $__env->startSection('title', 'Admin'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                Admin Panel
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Statistic
                </div>
                <div class="profile__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="profile__main">
                        <div class="counter__inner ">
                            <div class="counter__title">
                                User counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\User::count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Category counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Blog\Category::count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Posts counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Blog\Post::count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Topic counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Forum\Topic::count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Rubric counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Forum\Rubric::count()); ?>

                            </div>
                        </div>
                        <div class="counter__inner ">
                            <div class="counter__title">
                                Message counter
                            </div>
                            <div class="counter">
                                <?php echo e(\App\Models\Forum\Message::count()); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/admin/index.blade.php ENDPATH**/ ?>