<?php $__env->startSection('title', 'Rubric'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Rubric
            </div>
            <div class="category__inner">
                <?php echo $__env->make('layout.ForumMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="category__list">
                    <?php $__currentLoopData = $rubrics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rubric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category__item">
                            <div class="category__item-title">
                                <a href="<?php echo e(route('forum.rubric.show', $rubric->id)); ?>" class="category__title-link">
                                    <?php echo e(strip_tags($rubric['title'])); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/forum/rubric/index.blade.php ENDPATH**/ ?>