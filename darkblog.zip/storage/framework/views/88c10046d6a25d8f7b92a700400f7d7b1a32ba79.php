<?php $__env->startSection('title', 'Product'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Product
            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="product__list">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="product__item" title="<?php echo e($product->title); ?>">
                            <div class="product__item-image">
                                <img src="
                                    <?php if($product->file != null): ?>
                                        <?php echo e(Storage::url($product->file)); ?>

                                    <?php else: ?>
                                        <?php echo e(asset('not-photo.jpg')); ?>

                                    <?php endif; ?>" alt="Фото продукта">
                                <div class="product__setting">
                                    <a class="setting__card" title="Добавить в корзину" href="<?php echo e(route('shop.card.store', $product->id)); ?>">
                                        <?php if($product->amount != 0 AND $product->user_id != Auth::id()): ?>
                                            <img src="https://img.icons8.com/dusk/32/000000/shopping-basket-2.png"/>
                                        <?php endif; ?>
                                    </a>
                                    <div class="setting__favorite">
                                        <?php echo $__env->make('layout.shop_favorite_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="product__title">
                                <?php echo e($product->title); ?>

                            </div>
                            <div class="product__info">
                                <div class="product__price">
                                    <?php echo e($product->price); ?>$
                                </div>
                                <?php if($product->discount > 0): ?>
                                    <div class="product__price-discount">
                                        <?php echo e($product->price * ((100 - $product->discount) / 100)); ?>$
                                    </div>
                                <?php endif; ?>
                                <div class="product__amount">
                                    <?php echo e($product->amount); ?>

                                </div>
                            </div>
                            <a href="<?php echo e(route("shop.product.show", $product->id)); ?>" class="product__item-link">

                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php echo e($products->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/product/index.blade.php ENDPATH**/ ?>