<div class="profile__nav">
    <ul class="blog__nav-list">
        <li class="blog__nav-list-item">
            <a href="<?php echo e(route('profile.index', $nickname)); ?>" class="blog__item-link">
                Personal Data
            </a>
        </li>
        <li class="profile__list-item">
            <a href="<?php echo e(route("profile.statistic.index", $nickname)); ?>" class="profile__item-link">
                Statistic
            </a>
        </li>





        <?php if($nickname == Auth::getUser()->nickname): ?>
            <li class="profile__list-item">
                <a href="<?php echo e(route('profile.balance.index', $nickname)); ?>" class="profile__item-link">
                    Balance
                </a>
            </li>
        <?php endif; ?>
        <?php if($nickname == Auth::getUser()->nickname): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view', auth()->user())): ?>
                <li class="profile__list-item">
                    <a href="<?php echo e(route('admin.index')); ?>" class="profile__item-link">
                        Admin panel
                    </a>
                </li>
            <?php endif; ?>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH D:\darkblog\resources\views/layout/profileMenu.blade.php ENDPATH**/ ?>