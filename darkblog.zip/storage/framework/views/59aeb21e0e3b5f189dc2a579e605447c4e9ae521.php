<?php $__env->startSection('title', 'Add post'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Category
                <a href="<?php echo e(route('addcategory')); ?>" class="create-btn">
                    Create
                </a>
            </div>
            <div class="category__inner">
                <div class="profile__nav">
                    <ul class="blog__nav-list">
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('blog')); ?>" class="blog__item-link">
                                Post
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('myblog')); ?>" class="blog__item-link">
                                MyBlog
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="<?php echo e(route('category')); ?>" class="blog__item-link">
                                Category
                            </a>
                        </li>
                        <li class="blog__nav-list-item">
                            <a href="" class="blog__item-link">
                                Favorite
                            </a>
                        </li>
                    </ul>
                </div>
                <div class="category__list">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="category__item">
                            <div class="category__item-title">
                                <a href="<?php echo e(route('categoryPost', $category->id)); ?>" class="category__title-link">
                                    <?php echo e(strip_tags($category['title'])); ?>

                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/start/index.blade.php ENDPATH**/ ?>
