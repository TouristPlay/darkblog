<?php $__env->startSection('title', 'Registration'); ?>
<?php $__env->startSection('link-text', 'Log In'); ?>
<?php $__env->startSection('link-route', route('login')); ?>

<?php $__env->startSection('content'); ?>

    <section class="register">
        <div class="container">
            <span class="register__title">
                    DarkBlog Registration

            </span>
            <form action="<?php echo e(route('register')); ?>" class="register__form" method="post" autocomplete="off">
                <?php echo csrf_field(); ?>
                <div class="form__inner">
                    <div class="register__form-left">
                        <label class="register-label">
                            <span class="label__text">
                                Enter your name
                            </span>
                            <input autofocus type="text" class="register__input" value="<?php echo e(old('name')); ?>" name="name" placeholder="John">
                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label class="register-label">
                            <span class="label__text">
                                Enter last name
                            </span>
                            <input type="text" class="register__input" value="<?php echo e(old('lastname')); ?>" name="lastname" placeholder="Miller">
                            <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label class="register-label">
                            <span class="label__text">
                                Enter nickname
                            </span>
                            <input type="text" class="register__input"  value="<?php echo e(old('nickname')); ?>" name="nickname" placeholder="Hacker343">
                            <?php $__errorArgs = ['nickname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                    </div>
                    <div class="register__form-right">
                        <label class="register-label">
                            <span class="label__text">
                                Enter your mail
                            </span>
                            <input type="email" class="register__input" value="<?php echo e(old('email')); ?>" name="email" placeholder="Hacker343@gmail.com">
                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label class="register-label">
                            <span class="label__text">
                                Enter password
                            </span>
                            <input type="password" class="register__input" name="password">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                        <label class="register-label">
                            <span class="label__text">
                                Confirm password
                            </span>
                            <input type="password" class="register__input" name="password_confirmation">
                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="form_error-msg"><?php echo e($message); ?></div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </label>
                    </div>
                </div>
                <input type="submit" value="Register" class="register__form-btn">
            </form>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.layout-start', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/start/register.blade.php ENDPATH**/ ?>