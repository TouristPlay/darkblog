<?php $__env->startSection('title', 'Add post'); ?>

<?php $__env->startSection('content'); ?>
    <section class="blog">
        <div class="container">
            <div class="blog__title">
                Create category
            </div>
            <div class="category__inner">
                <?php echo $__env->make('layout.sidebarMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <form action="<?php echo e(route('admin.categories.store')); ?>" method="post" autocomplete="off" class="addcategory__form">
                    <?php echo csrf_field(); ?>
                    <label class="category__lable">
                        <div class="lable__text">
                            Enter category
                        </div>
                        <input autofocus type="text" class="category__input" placeholder="Hack" name="title">
                        <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="form_error-msg"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </label>
                    <input type="submit" class="category-btn" value="Create">
                </form>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH G:\Web-Development\PHP\darkblog\resources\views/blog/category/create.blade.php ENDPATH**/ ?>
