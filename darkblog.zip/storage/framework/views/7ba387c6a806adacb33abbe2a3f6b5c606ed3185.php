<?php $__env->startSection('title', 'Products'); ?>


<?php $__env->startSection('content'); ?>
    <section class="profile">
        <div class="container">
            <div class="profile__title">
                <a href="<?php echo e(route('admin.index')); ?>" class="admin-link">
                    Admin Panel
                </a>
            </div>
            <div class="profile__info">
                <div class="profile_info-title">
                    Products
                </div>
                <div class="users__inner">
                    <?php echo $__env->make('layout.adminMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div class="users__main">
                        <table class="table admin__Products">
                            <thead>
                                <tr>
                                    <th scope="col">#</th>
                                    <th scope="col">Title</th>
                                    <th scope="col">Nickname</th>
                                    <th scope="col">Category</th>
                                    <th scope="col">Favorite</th>
                                    <th scope="col">Price</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                               <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <tr>
                                       <th title="Product ID" scope="row"><?php echo e($product->id); ?></th>
                                       <td title="Product title">
                                           <a href="<?php echo e(route('shop.product.show', $product->id)); ?>" class="link">
                                               <?php echo e($product->title); ?>

                                           </a>
                                       </td>
                                       <td title="User nickname">
                                           <a href="<?php echo e(route('profile.index', \App\Models\User::find($product->user_id)->nickname)); ?>" class="link">
                                               <?php echo e(\App\Models\User::find($product->user_id)->nickname); ?>

                                           </a>
                                       </td>
                                       <td title="Product Category title">
                                           <a  href="<?php echo e(route('shop.category.show', $product->category_id)); ?>" class="link">
                                               <?php echo e(\App\Models\Shop\ProductCategory::withTrashed()->find($product->category_id)->title); ?>

                                           </a>
                                       </td>
                                       <td title="Favorite Counter"><?php echo e($product->favorite_counter); ?></td>
                                       <td title="Price">
                                           <?php echo e($product->price); ?>

                                       </td>
                                       <td>
                                           <?php if($product->deleted_at == null): ?>
                                               <a href="<?php echo e(route('admin.products.delete', $product->id)); ?>" title="Delete Product" class="admin-delete">
                                                   <img src="https://img.icons8.com/external-kiranshastry-lineal-color-kiranshastry/20/000000/external-delete-multimedia-kiranshastry-lineal-color-kiranshastry.png"/>
                                               </a>
                                           <?php else: ?>
                                               <a href="<?php echo e(route('admin.products.restore', $product->id)); ?>" title="Restore Product" class="admin-delete">
                                                   <img src="https://img.icons8.com/fluency/20/000000/settings-backup-restore.png"/>
                                               </a>
                                           <?php endif; ?>
                                       </td>
                                   </tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php echo e($products->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/admin/products/index.blade.php ENDPATH**/ ?>