<?php $__env->startSection('title', $product->title); ?>

<?php $__env->startSection('content'); ?>
    <section class="card">
        <div class="container">
            <div class="blog__title">
                <?php echo e($product->title); ?>

            </div>
            <div class="product__inner">
                <?php echo $__env->make('layout.shopMenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="card__list">
                    <div class="show__item">
                        <div class="show__info">
                            <div class="show__image">
                                <?php if($product->file != null): ?>
                                    <img src="<?php echo e(Storage::url($product->file)); ?>" alt="">
                                <?php else: ?>
                                    <img src="<?php echo e(asset('not-photo.jpg')); ?>" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="show__inner">
                                <div class="show-inner__header">
                                    <a class="look-internet__link" href="https://www.google.com/search?q=<?php echo e($product->title); ?>">
                                        Search on the Internet
                                    </a>
                                    <div class="product__amount">
                                        <?php echo e($product->amount); ?>

                                    </div>
                                    <div class="show__setting-favorite">
                                        <?php echo $__env->make('layout.shop_favorite_icon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                                <div class="show__setting-add">
                                    <a href="<?php echo e(route('shop.card.store', $product->id)); ?>" class="setting-add__link <?php if($product->user_id == Auth::id()): ?> disable <?php endif; ?>">
                                        Add to Cart
                                    </a>
                                </div>
                                <div class="product__info">
                                    <div class="product__price">
                                        <?php echo e($product->price); ?>$
                                    </div>
                                    <?php if($product->discount > 0): ?>
                                        <div class="product__price-discount">
                                            <?php echo e($product->price * ((100 - $product->discount) / 100)); ?>$
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <div class="show__text">
                            <?php echo $product->content; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.main-layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\darkblog\resources\views/shop/product/show.blade.php ENDPATH**/ ?>